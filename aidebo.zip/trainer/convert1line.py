import re
import sys

def source_file_to_single_line(input_filepath, output_filepath):
    """
    Converts a source code file to a single-line string.

    Args:
        input_filepath: Path to the input source code file.
        output_filepath: Path to the output single-line text file.
    """
    try:
        with open(input_filepath, 'r', encoding='utf-8') as infile:
            content = infile.read()

        content = re.sub(r'//.*', '', content)
        content = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)
        content = content.replace('\n', ' ')
        content = re.sub(r'\s+', ' ', content).strip()

        with open(output_filepath, 'w', encoding='utf-8') as outfile:
            outfile.write(content)

        print(f"Successfully converted '{input_filepath}' to '{output_filepath}'")

    except FileNotFoundError:
        print(f"Error: Input file '{input_filepath}' not found.")
    except Exception as e:
        print(f"An error occurred: {e}")


if __name__ == "__main__":  # This ensures the code only runs when the script is executed directly
    if len(sys.argv) != 3:
        print("Usage: python thisfile inputfilename outputfilename")
        sys.exit(1)  # Indicate an error

    input_file = sys.argv[1]
    output_file = sys.argv[2]
    source_file_to_single_line(input_file, output_file)
    