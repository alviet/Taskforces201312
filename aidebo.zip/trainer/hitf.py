import tensorflow as tf # type: ignore
import numpy as np # type: ignore

print("TensorFlow version:", tf.__version__)

# Tạo dữ liệu mẫu
X = np.array([[1], [2], [3], [4]], dtype=float)
y = np.array([[2], [4], [6], [8]], dtype=float)

# Chuẩn hóa dữ liệu
print(X)
X = tf.keras.utils.normalize(X)
print(X)