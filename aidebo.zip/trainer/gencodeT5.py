import chromadb
import tensorflow as tf # type: ignore
from transformers import AutoTokenizer, TFAutoModelForSeq2SeqLM

# Khởi tạo ChromaDB để lưu embeddings
db = chromadb.PersistentClient(path="./code_vector_db")
collection = db.get_or_create_collection("code_embeddings")

# Lưu code vào DB
code_snippet = "def add(a, b): return a + b"
collection.add(documents=[code_snippet], ids=["code_1"])

# Dùng CodeT5 để xử lý mã nguồn
model_name = "Salesforce/codet5-small"
tokenizer = AutoTokenizer.from_pretrained(model_name)
# model = TFAutoModelForSeq2SeqLM.from_pretrained(model_name)
model = TFAutoModelForSeq2SeqLM.from_pretrained(model_name, from_pt=True)

# Token hóa code
tokens = tokenizer(code_snippet, return_tensors="tf", padding=True, truncation=True)
tokens_tensor = tf.convert_to_tensor(tokens["input_ids"])
print("🔹 Tokenized Code:", tokens_tensor)

# 🔍 Giải thích code
explain_prompt = "Explain the following Python code:"
explain_input = tokenizer(explain_prompt + code_snippet, return_tensors="tf", padding=True, truncation=True)
explain_output = model.generate(explain_input["input_ids"], max_length=100)
explanation = tokenizer.decode(explain_output[0], skip_special_tokens=True)
print("📝 Code Explanation:", explanation)

# 💡 Sinh code: Thêm phép cộng 3 số
generate_prompt = "Rewrite the following function to add three numbers:"
generate_input = tokenizer(generate_prompt + code_snippet, return_tensors="tf", padding=True, truncation=True)
generate_output = model.generate(generate_input["input_ids"], max_length=100)
generated_code = tokenizer.decode(generate_output[0], skip_special_tokens=True)
print("💡 Generated Code:", generated_code)
