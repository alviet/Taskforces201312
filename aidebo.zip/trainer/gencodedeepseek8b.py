import ollama

# Đọc nội dung từ file inputcode.txt
with open("inputcode.txt", "r", encoding="utf-8") as file:
    input_code = file.read().strip()

# Prompt để giải thích code
explain_prompt = f"Explain this code:\n{input_code}"
explain_response = ollama.chat(model="deepseek-r1:8b", messages=[{"role": "user", "content": explain_prompt}])

# Prompt để sinh code mới
generate_prompt = f"Generate a C++ to use hanoitower funciton based from this:\n{input_code}"
generate_response = ollama.chat(model="deepseek-r1:8b", messages=[{"role": "user", "content": generate_prompt}])

# Kết quả
print("📝 Code Explanation:", explain_response['message']['content'])
print("💡 Generated Code:", generate_response['message']['content'])
