import ollama

# Đoạn code cần phân tích
# input_code = "def add(a, b): return a + b"
# input_code = ""

# Prompt để giải thích code
explain_prompt = f"Explain this Python function:\n{input_code}"
explain_response = ollama.chat(model="llama3.2:latest", messages=[{"role": "user", "content": explain_prompt}])

# Prompt để sinh code mới
generate_prompt = f"Generate a Python function to add three numbers based on this function:\n{input_code}"
generate_response = ollama.chat(model="llama3.2:latest", messages=[{"role": "user", "content": generate_prompt}])

# Kết quả
print("📝 Code Explanation:", explain_response['message']['content'])
print("💡 Generated Code:", generate_response['message']['content'])
