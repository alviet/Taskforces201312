# import warnings
# from urllib3 import NotOpenSSLWarning
# warnings.filterwarnings("ignore", category=NotOpenSSLWarning)

from transformers import AutoTokenizer, pipeline
import tensorflow as tf  # type: ignore
import chromadb

# 1️⃣ Kết nối với ChromaDB để lưu trữ embedding
db = chromadb.PersistentClient(path="./code_vector_db")
collection = db.get_or_create_collection("code_embeddings")

# 2️⃣ Khởi tạo tokenizer
MODEL_NAME = "huggingface/CodeBERTa-small-v1"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)

# 3️⃣ Kiểm tra nếu mã đã có trong database
results = collection.get(include=['documents'])
if results['documents']:
    code = results['documents'][0]  # Lấy code đã lưu
    print("🔄 Lấy code từ database")
else:
    code = "def add(a, b): return a + b"  # Code mặc định nếu chưa có
    collection.add(documents=[code], ids=["code_1"])
    print("✅ Lưu code vào database")

# 4️⃣ Tokenize và lưu token nếu chưa có
tokens = tokenizer.tokenize(code)
tokens_tensor = tf.convert_to_tensor(tokens)

collection.add(documents=[str(tokens)], ids=["token_1"])
collection.add(documents=[str(tokens_tensor.numpy().tolist())], ids=["tensor_1"])

print("🔤 Tokens:", tokens)
print("🔢 Tensor:", tokens_tensor.numpy())

# 5️⃣ Dùng mô hình Transformer để giải thích code
explain_model = pipeline("text2text-generation", model="Salesforce/codet5-small")
explanation = explain_model(f"Explain this code: {code}", max_length=100)
print("📝 Code Explanation:", explanation[0]['generated_text'])

# 6️⃣ Sinh code cộng 3 số
new_code = explain_model("Generate Python function to add three numbers", max_length=50)
print("💡 Generated Code:", new_code[0]['generated_text'])
