from transformers import AutoTokenizer, TFAutoModelForSeq2SeqLM

# Load tokenizer và model từ PyTorch weights
model_name = "Salesforce/codet5-small"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = TFAutoModelForSeq2SeqLM.from_pretrained(model_name, from_pt=True)

# Đoạn code input cần giải thích
input_code = "def add(a, b): return a + b"

# **Thêm prefix giúp model hiểu ngữ cảnh**
explain_prompt = f"Explain: {input_code}"
generate_prompt = f"Generate: {input_code}"

# Tokenize input
inputs = tokenizer(explain_prompt, return_tensors="tf", padding=True, truncation=True)
generate_inputs = tokenizer(generate_prompt, return_tensors="tf", padding=True, truncation=True)

# Dự đoán giải thích code
output_tokens = model.generate(**inputs, max_length=50)
explanation = tokenizer.decode(output_tokens[0], skip_special_tokens=True)

# Dự đoán sinh code mới
gen_output_tokens = model.generate(**generate_inputs, max_length=50, do_sample=True, temperature=0.9, top_k=50, top_p=0.95)
generated_code = tokenizer.decode(gen_output_tokens[0], skip_special_tokens=True)

print("📝 Code Explanation:", explanation)
print("💡 Generated Code:", generated_code)
