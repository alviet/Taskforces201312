import os
from pathlib import Path

# Define the folder containing text files and the output file
folder_path = '/root/source_code/trained_code'  # Replace with the path to your folder
output_file = '/root/source_code/combined.txt'  # Output in current directory

# List of file extensions to include
text_file_extensions = {'.txt', '.kt', '.dart', '.py', '.java', '.js'}  # Using set for faster lookup

def combine_text_files(folder_path, output_file):
    try:
        # Create output directory if it doesn't exist
        output_dir = os.path.dirname(output_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # Open the output file in write mode with UTF-8 encoding
        with open(output_file, 'w', encoding='utf-8') as outfile:
            # Walk through all subdirectories
            for root, _, files in os.walk(folder_path):
                for filename in files:
                    # Check if the file has a text-based extension
                    if Path(filename).suffix.lower() in text_file_extensions:
                        file_path = os.path.join(root, filename)
                        try:
                            # Try reading with UTF-8 encoding first
                            with open(file_path, 'r', encoding='utf-8') as infile:
                                content = infile.read()
                                # Write file path as a header
                                relative_path = os.path.relpath(file_path, folder_path)
                                outfile.write(f"\n\n### File: {relative_path}\n")
                                outfile.write(content)
                                print(f"✅ Added {relative_path}")
                        except UnicodeDecodeError:
                            try:
                                # Try with another common encoding if UTF-8 fails
                                with open(file_path, 'r', encoding='latin-1') as infile:
                                    content = infile.read()
                                    relative_path = os.path.relpath(file_path, folder_path)
                                    outfile.write(f"\n\n### File: {relative_path}\n")
                                    outfile.write(content)
                                    print(f"✅ Added {relative_path} (using latin-1 encoding)")
                            except Exception as e:
                                print(f"❌ Error reading {filename}: {str(e)}")
                        except Exception as e:
                            print(f"❌ Error processing {filename}: {str(e)}")
        
        print(f"\n✅ All text files combined into {output_file}")
    except Exception as e:
        print(f"❌ Error: {str(e)}")

if __name__ == "__main__":
    combine_text_files(folder_path, output_file)