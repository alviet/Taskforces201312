from llama_index.core import StorageContext, load_index_from_storage
from llama_index.llms.ollama import Ollama

# ✅ Ensure that the embedding model is also local (optional step to fix any OpenAI reliance)
from llama_index.embeddings.huggingface import HuggingFaceEmbedding

# Define the storage context and load the index
storage_context = StorageContext.from_defaults(persist_dir="/root/vector_db")
index = load_index_from_storage(storage_context=storage_context)

print("✅ Index loaded successfully!")

# ✅ Ensure no OpenAI model is used (Force Ollama locally)
llm = Ollama(model="mistral")  # Change "mistral" to the Ollama model you have installed

# ✅ Optionally use a local embedding model instead of OpenAI
embed_model = HuggingFaceEmbedding(model_name="sentence-transformers/all-MiniLM-L6-v2")

# ✅ Set local embedding model (if needed)
from llama_index.settings import Settings
Settings.embed_model = embed_model
Settings.llm = llm

# ✅ Create the query engine with Ollama as the LLM
query_engine = index.as_query_engine(llm=llm)

# ✅ Run a query
question = "What is LinkText in the source code?"
response = query_engine.query(question)

# ✅ Print the response
print("🔍 Query Result:")
print(response)
