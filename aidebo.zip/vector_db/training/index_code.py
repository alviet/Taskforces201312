from llama_index.core import SimpleDirectoryReader, VectorStoreIndex, Settings
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
import chromadb

# 1️⃣ Load all Dart source files
reader = SimpleDirectoryReader(input_dir="/root/source_code", recursive=True)
documents = reader.load_data()

# 2️⃣ Use a local embedding model (no OpenAI API key needed)
embed_model = HuggingFaceEmbedding(model_name="sentence-transformers/all-MiniLM-L6-v2")

# 3️⃣ Set the embedding model globally
Settings.embed_model = embed_model

# 4️⃣ Create a vector index with local embeddings
index = VectorStoreIndex.from_documents(documents)

# 5️⃣ Save to ChromaDB
index.storage_context.persist(persist_dir="/root/vector_db")

print("✅ Source code has been indexed and stored in ChromaDB using local embeddings!")
