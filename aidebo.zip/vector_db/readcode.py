import os
import ollama
from langchain.text_splitter import RecursiveCharacterTextSplitter
# from langchain_ollama import OllamaEmbeddings
# from langchain_community.vectorstores import Chroma
# from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.document_loaders import DirectoryLoader


# Path to your app's source code
SOURCE_CODE_DIR = "/Users/joshnguyen/WORK/myai/link_text-master"

# Load all source code files
loader = DirectoryLoader(SOURCE_CODE_DIR, glob="**/*.py", show_progress=True)
documents = loader.load()

# Split text into smaller chunks
text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
docs = text_splitter.split_documents(documents)

# Convert code into embeddings
embeddings = OllamaEmbeddings(model="mistral")  # Replace with a preferred local model
vector_store = Chroma.from_documents(docs, embeddings, persist_directory="./vector_db")

# Save the vector database
vector_store.persist()
print("Codebase indexed successfully!")
